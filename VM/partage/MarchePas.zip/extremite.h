#ifndef ___EXTREMITE___
#define ___EXTREMITE___

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>
#include <netdb.h>

#include "iftun.h"

#define MAXLIGNE 80

int ext_out(char* port, int tunfd);
int ext_in(char * hote, char* port, int tunfd);
void echo(int n, int tunfd);

#endif